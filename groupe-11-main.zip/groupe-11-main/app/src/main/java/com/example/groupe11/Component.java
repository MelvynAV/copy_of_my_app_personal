package com.example.groupe11;

import android.widget.EditText;

import java.time.LocalDateTime;

public class Component {
    private final String type;
    private final String subType;
    private final String title;
    private int quantity;
    private String comment;
    private final LocalDateTime creationDateTime;
    private LocalDateTime modificationDateTime;

    public Component(String type, String subType, String title, int quantity, LocalDateTime creationDateTime, LocalDateTime modificationDateTime){
        this.type = type;
        this.subType = subType;
        this.title = title;
        this.quantity = quantity;
        this.creationDateTime = LocalDateTime.now();
        this.modificationDateTime = LocalDateTime.now();
    }

    public String getType() { return type; }
    public String getSubType() { return subType; }
    public String getTitle() { return title; }
    public int getQuantity() { return quantity; }
    public String getComment() { return comment; }
    public LocalDateTime getCreationDateTime() { return creationDateTime; }
    public LocalDateTime getModificationDateTime() { return modificationDateTime; }

    public void setQuantity(int quantity){
        this.quantity = quantity;
        updateModificationDateTime();
    }

    public void setComment(String comment){
        this.comment = comment;
        updateModificationDateTime();
    }


    private void updateModificationDateTime(){
        this.modificationDateTime = LocalDateTime.now();
    }
}
