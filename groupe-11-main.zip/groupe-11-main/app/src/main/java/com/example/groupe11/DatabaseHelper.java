package com.example.groupe11;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "pc_management_updated.db";
    private static final int DATABASE_VERSION = 2;

    // Table for users
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_ROLE = "role";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Table for stock
    private static final String TABLE_STOCK = "stock";
    private static final String COLUMN_STOCK_ID = "stock_id";
    private static final String COLUMN_TYPE = "type";
    private static final String COLUMN_SUBTYPE = "subtype";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_QUANTITY = "quantity";
    private static final String COLUMN_COMMENT = "comment";
    private static final String COLUMN_CREATION_TIME = "creation_time";
    private static final String COLUMN_MODIFICATION_TIME = "modification_time";

    // Table for orders
    private static final String TABLE_ORDERS = "orders";
    private static final String COLUMN_ORDER_ID = "order_id";
    private static final String COLUMN_STATUS = "status";
    private static final String COLUMN_REQUESTER_ID = "requester_id";
    private static final String COLUMN_ORDER_DATE = "order_date";

    // Table for order details
    private static final String TABLE_ORDER_DETAILS = "order_details";
    private static final String COLUMN_ORDER_DETAIL_ID = "order_detail_id";
    private static final String COLUMN_COMPONENT_ID = "component_id";
    private static final String COLUMN_QUANTITY_ORDERED = "quantity";

    // SQL statements to create tables
    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS + " (" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_ROLE + " TEXT NOT NULL, " +
            COLUMN_USERNAME + " TEXT UNIQUE NOT NULL, " +
            COLUMN_PASSWORD + " TEXT NOT NULL);";

    private static final String CREATE_TABLE_STOCK = "CREATE TABLE " + TABLE_STOCK + " (" +
            COLUMN_STOCK_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_TYPE + " TEXT NOT NULL, " +
            COLUMN_SUBTYPE + " TEXT NOT NULL, " +
            COLUMN_TITLE + " TEXT UNIQUE NOT NULL, " +
            COLUMN_QUANTITY + " INTEGER NOT NULL, " +
            COLUMN_COMMENT + " TEXT, " +
            COLUMN_CREATION_TIME + " TEXT NOT NULL, " +
            COLUMN_MODIFICATION_TIME + " TEXT NOT NULL);";

    private static final String CREATE_TABLE_ORDERS = "CREATE TABLE " + TABLE_ORDERS + " (" +
            COLUMN_ORDER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_STATUS + " TEXT NOT NULL, " +
            COLUMN_REQUESTER_ID + " INTEGER NOT NULL, " +
            COLUMN_ORDER_DATE + " TEXT NOT NULL, " +
            "FOREIGN KEY (" + COLUMN_REQUESTER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_ID + "));";

    private static final String CREATE_TABLE_ORDER_DETAILS = "CREATE TABLE " + TABLE_ORDER_DETAILS + " (" +
            COLUMN_ORDER_DETAIL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_ORDER_ID + " INTEGER NOT NULL, " +
            COLUMN_COMPONENT_ID + " INTEGER NOT NULL, " +
            COLUMN_QUANTITY_ORDERED + " INTEGER NOT NULL, " +
            "FOREIGN KEY (" + COLUMN_ORDER_ID + ") REFERENCES " + TABLE_ORDERS + "(" + COLUMN_ORDER_ID + "), " +
            "FOREIGN KEY (" + COLUMN_COMPONENT_ID + ") REFERENCES " + TABLE_STOCK + "(" + COLUMN_STOCK_ID + "));";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_STOCK);
        db.execSQL(CREATE_TABLE_ORDERS);
        db.execSQL(CREATE_TABLE_ORDER_DETAILS);
        insertDefaultUsers(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STOCK);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORDERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORDER_DETAILS);
        onCreate(db);
    }

    private void insertDefaultUsers(SQLiteDatabase db) {
        addUserInternal(db, "Administrator", "admin@example.com", "admin123");
        addUserInternal(db, "StoreKeeper", "storekeeper@example.com", "storekeeper123");
        addUserInternal(db, "Assembler", "assembler@example.com", "assembler123");
    }

    private void addUserInternal(SQLiteDatabase db, String role, String username, String password) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_ROLE, role);
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        db.insert(TABLE_USERS, null, values);
    }

    // Method to add a new user
    public boolean addUser(String role, String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ROLE, role);
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }
    public List<String> getAllComponentTitles() {
        List<String> titles = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT title FROM stock WHERE quantity > 0", null);
        while (cursor.moveToNext()) {
            titles.add(cursor.getString(0));
        }
        cursor.close();
        return titles;
    }


    // Method to delete a user
    public boolean deleteUser(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(TABLE_USERS, COLUMN_USERNAME + "=?", new String[]{username});
        return rowsDeleted > 0;
    }

    // Method to update a user's password
    public boolean updateUser(String username, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PASSWORD, newPassword);
        int rowsUpdated = db.update(TABLE_USERS, values, COLUMN_USERNAME + "=?", new String[]{username});
        return rowsUpdated > 0;
    }

    // Method to initialize default users
    public void initializeDatabase() {
        SQLiteDatabase db = this.getWritableDatabase();
        insertDefaultUsers(db);
    }

    // Method to clear the users table
    public void clearDatabase() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_USERS, null, null);
    }

    // Method to reset the users table
    public void resetDatabase() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_USERS);
        insertDefaultUsers(db);
    }

    // Method to reset stock
    public void resetStock() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_STOCK);
    }

    // Method to authenticate user
    public boolean authenticateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null, COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password}, null, null, null);
        boolean isAuthenticated = cursor.getCount() > 0;
        cursor.close();
        return isAuthenticated;
    }

    // Method to get user role
    public String getUserRole(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_ROLE}, COLUMN_USERNAME + "=?",
                new String[]{username}, null, null, null);
        String role = null;
        if (cursor.moveToFirst()) {
            role = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ROLE));
        }
        cursor.close();
        return role;
    }

    public Cursor getPendingOrders() {
        SQLiteDatabase db = this.getReadableDatabase();
        // Explicitly fetch order_id, order_date, and status columns
        return db.rawQuery("SELECT order_id, order_date, status FROM " + TABLE_ORDERS + " WHERE status = 'Pending'", null);
    }



    // Fetch accepted orders
    public Cursor getAcceptedOrders() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM orders WHERE status = ?", new String[]{"Accepted"});
    }

    // Fetch shipped orders
    public Cursor getShippedOrders() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM orders WHERE status = ?", new String[]{"Shipped"});
    }

    // Check if stock is sufficient for a given order
    public boolean isStockAvailable(String orderId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT od.component_id, od.quantity, s.quantity AS stock " +
                "FROM order_details od INNER JOIN stock s " +
                "ON od.component_id = s.stock_id " +
                "WHERE od.order_id = ?", new String[]{orderId});

        boolean isAvailable = true;
        while (cursor.moveToNext()) {
            @SuppressLint("Range") int required = cursor.getInt(cursor.getColumnIndex("quantity"));
            @SuppressLint("Range") int stock = cursor.getInt(cursor.getColumnIndex("stock"));
            if (required > stock) {
                isAvailable = false;
                break;
            }
        }
        cursor.close();
        return isAvailable;
    }

    // Accept an order
    public boolean acceptOrder(String orderId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_STATUS, "Accepted");
        int rows = db.update(TABLE_ORDERS, values, COLUMN_ORDER_ID + "=?", new String[]{orderId});
        return rows > 0;
    }
    // Method to add an order
    public boolean addOrder(String caseType, String motherboard, String ram, int ramQty,
                            String hardDrive, int hardDriveQty, String keyboardMouse,
                            String monitor, int monitorQty, String web, String officeSuite,
                            int officeSuiteQty, String devTools, int devToolsQty, String requesterId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues orderValues = new ContentValues();
        orderValues.put(COLUMN_STATUS, "Pending"); // Assuming new orders are pending
        orderValues.put(COLUMN_REQUESTER_ID, requesterId);
        orderValues.put(COLUMN_ORDER_DATE, getCurrentDate());

        long orderId = db.insert(TABLE_ORDERS, null, orderValues);

        if (orderId == -1) {
            return false;  // Failed to insert order
        }

        // Now insert the order details (components)
        ContentValues orderDetailValues = new ContentValues();
        orderDetailValues.put(COLUMN_ORDER_ID, orderId);

        // Insert case
        orderDetailValues.put(COLUMN_COMPONENT_ID, getComponentId(caseType)); // Assuming getComponentId is a method to get component ID
        orderDetailValues.put(COLUMN_QUANTITY_ORDERED, 1);  // Assuming 1 quantity for each component
        db.insert(TABLE_ORDER_DETAILS, null, orderDetailValues);

        // Insert motherboard, ram, harddrive, etc.
        // Repeat the process for other components...

        return true;
    }

    // Helper method to get the component ID based on type
    @SuppressLint("Range")
    private int getComponentId(String componentTitle) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_STOCK, new String[]{COLUMN_STOCK_ID},
                COLUMN_TITLE + "=?", new String[]{componentTitle}, null, null, null);
        int componentId = -1;
        if (cursor.moveToFirst()) {
            componentId = cursor.getInt(cursor.getColumnIndex(COLUMN_STOCK_ID));
        }
        cursor.close();
        return componentId;
    }

    // Helper method to get the current date
    private String getCurrentDate() {
        // Return the current date in the desired format (example: yyyy-MM-dd)
        return new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(new java.util.Date());
    }


    // Reject an order
    public boolean rejectOrder(String orderId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_STATUS, "Rejected");
        int rows = db.update(TABLE_ORDERS, values, COLUMN_ORDER_ID + "=?", new String[]{orderId});
        return rows > 0;
    }

    // Assemble and ship an order
    public boolean assembleAndShipOrder(String orderId) {
        if (!isStockAvailable(orderId)) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT component_id, quantity FROM order_details WHERE order_id = ?", new String[]{orderId});

        while (cursor.moveToNext()) {
            @SuppressLint("Range") int componentId = cursor.getInt(cursor.getColumnIndex("component_id"));
            @SuppressLint("Range") int quantity = cursor.getInt(cursor.getColumnIndex("quantity"));
            db.execSQL("UPDATE stock SET quantity = quantity - ? WHERE stock_id = ?", new Object[]{quantity, componentId});
        }
        cursor.close();

        ContentValues values = new ContentValues();
        values.put(COLUMN_STATUS, "Shipped");
        int rows = db.update(TABLE_ORDERS, values, COLUMN_ORDER_ID + "=?", new String[]{orderId});
        return rows > 0;
    }
    // Dans DatabaseHelper.java
    public boolean addStockItem(String type, String subType, String title, int quantity, String comment, String creationTime, String modificationTime) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TYPE, type);
        values.put(COLUMN_SUBTYPE, subType);
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_QUANTITY, quantity);
        values.put(COLUMN_COMMENT, comment);
        values.put(COLUMN_CREATION_TIME, creationTime);
        values.put(COLUMN_MODIFICATION_TIME, modificationTime);
        long result = db.insert(TABLE_STOCK, null, values);
        return result != -1;
    }

    public boolean updateStockItem(String title, Integer quantity, String comment, String modificationTime) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        if (quantity != null) values.put(COLUMN_QUANTITY, quantity);
        if (comment != null) values.put(COLUMN_COMMENT, comment);
        values.put(COLUMN_MODIFICATION_TIME, modificationTime);
        int rows = db.update(TABLE_STOCK, values, COLUMN_TITLE + "=?", new String[]{title});
        return rows > 0;
    }

    public boolean deleteStockItem(String title) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_STOCK, COLUMN_TITLE + "=?", new String[]{title});
        return rows > 0;
    }

    public List<String> getAllStockItems() {
        List<String> stockItems = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_STOCK, null);
        while (cursor.moveToNext()) {
            @SuppressLint("Range") String item = cursor.getString(cursor.getColumnIndex(COLUMN_TITLE)) + " (" +
                    cursor.getString(cursor.getColumnIndex(COLUMN_TYPE)) + "/" +
                    cursor.getString(cursor.getColumnIndex(COLUMN_SUBTYPE)) + ") [" +
                    cursor.getInt(cursor.getColumnIndex(COLUMN_QUANTITY)) + "]";
            stockItems.add(item);
        }
        cursor.close();
        return stockItems;
    }
    // Ajoute une commande et retourne son ID
    public long addOrderAndGetId(String caseType, String motherboard, String ram, int ramQty,
                                 String hardDrive, int hardDriveQty, String keyboardMouse,
                                 String monitor, int monitorQty, String web, String officeSuite,
                                 int officeSuiteQty, String devTools, int devToolsQty,
                                 String requesterId, String orderDate, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues orderValues = new ContentValues();
        orderValues.put(COLUMN_REQUESTER_ID, requesterId);
        orderValues.put(COLUMN_ORDER_DATE, orderDate);
        orderValues.put(COLUMN_STATUS, status);

        // Insérer dans la table 'orders'
        long orderId = db.insert(TABLE_ORDERS, null, orderValues);
        if (orderId == -1) {
            return -1; // Échec
        }

        // Insérer les détails des composants associés
        addOrderDetails(orderId, getComponentId(caseType), 1);
        addOrderDetails(orderId, getComponentId(motherboard), 1);
        addOrderDetails(orderId, getComponentId(ram), ramQty);
        addOrderDetails(orderId, getComponentId(hardDrive), hardDriveQty);
        addOrderDetails(orderId, getComponentId(monitor), monitorQty);
        addOrderDetails(orderId, getComponentId(keyboardMouse), 1);
        addOrderDetails(orderId, getComponentId(web), 1);
        addOrderDetails(orderId, getComponentId(officeSuite), officeSuiteQty);
        addOrderDetails(orderId, getComponentId(devTools), devToolsQty);

        return orderId;
    }




    public boolean addOrderDetails(long orderId, int componentId, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ORDER_ID, orderId);
        values.put(COLUMN_COMPONENT_ID, componentId);
        values.put(COLUMN_QUANTITY_ORDERED, quantity);
        return db.insert(TABLE_ORDER_DETAILS, null, values) != -1;
    }



}
