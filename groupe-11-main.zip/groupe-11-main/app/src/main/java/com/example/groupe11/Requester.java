package com.example.groupe11;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class Requester extends AppCompatActivity {

    private Button logout, orderButton;
    private Spinner cases, motherboards, ram, ramQTY, harddrives, harddrivesQTY, keyboardsmouse, monitors, monitorQTY, web, officesuite, officesuiteQTY, devtools, devtoolsQTY;
    private LinearLayout placedOrdersLayout;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requester);

        // Initialize the database helper
        dbHelper = new DatabaseHelper(this);

        // Initialize UI components
        logout = findViewById(R.id.logout);
        orderButton = findViewById(R.id.order_button);

        cases = findViewById(R.id.cases);
        motherboards = findViewById(R.id.motherboards);
        ram = findViewById(R.id.ram);
        ramQTY = findViewById(R.id.ramQTY);
        harddrives = findViewById(R.id.harddrives);
        harddrivesQTY = findViewById(R.id.harddrivesQTY);
        keyboardsmouse = findViewById(R.id.keyboard_mouse);
        monitors = findViewById(R.id.monitors);
        monitorQTY = findViewById(R.id.monitorQTY);
        web = findViewById(R.id.web);
        officesuite = findViewById(R.id.office_suite);
        officesuiteQTY = findViewById(R.id.office_suiteQTY);
        devtools = findViewById(R.id.dev_tools);
        devtoolsQTY = findViewById(R.id.dev_toolsQTY);

        placedOrdersLayout = findViewById(R.id.placed_orders);

        // Set up adapters for spinners
        setUpSpinners();

        // Logout button functionality
        logout.setOnClickListener(view -> {
            Intent intent = new Intent(Requester.this, WelcomePage.class);
            startActivity(intent);
            finish();
        });

        // Order button functionality
        orderButton.setOnClickListener(view -> placeOrder());

        // Load previously placed orders
        loadPlacedOrders();
    }
    @Override
    protected void onResume() {
        super.onResume();
        setUpSpinners(); // Recharge les données des cases déroulantes
    }



    private void placeOrder() {
        try {
            // Collect user inputs from UI elements
            String caseSelected = Objects.requireNonNull(cases.getSelectedItem()).toString();
            String motherboardSelected = Objects.requireNonNull(motherboards.getSelectedItem()).toString();
            String ramSelected = Objects.requireNonNull(ram.getSelectedItem()).toString();
            int ramQtyValue = Integer.parseInt(Objects.requireNonNull(ramQTY.getSelectedItem()).toString());
            String hardDriveSelected = Objects.requireNonNull(harddrives.getSelectedItem()).toString();
            int hardDriveQtyValue = Integer.parseInt(Objects.requireNonNull(harddrivesQTY.getSelectedItem()).toString());
            String monitorSelected = Objects.requireNonNull(monitors.getSelectedItem()).toString();
            int monitorQtyValue = Integer.parseInt(Objects.requireNonNull(monitorQTY.getSelectedItem()).toString());
            String keyboardMouseSelected = Objects.requireNonNull(keyboardsmouse.getSelectedItem()).toString();
            String webSelected = Objects.requireNonNull(web.getSelectedItem()).toString();
            String officeSuiteSelected = Objects.requireNonNull(officesuite.getSelectedItem()).toString();
            int officeSuiteQtyValue = Integer.parseInt(Objects.requireNonNull(officesuiteQTY.getSelectedItem()).toString());
            String devToolsSelected = Objects.requireNonNull(devtools.getSelectedItem()).toString();
            int devToolsQtyValue = Integer.parseInt(Objects.requireNonNull(devtoolsQTY.getSelectedItem()).toString());

            // Example user ID for the requester (replace with actual ID)
            String requesterId = "1";
            String creationTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

            // Save to database
            long orderId = dbHelper.addOrderAndGetId(caseSelected, motherboardSelected, ramSelected, ramQtyValue,
                    hardDriveSelected, hardDriveQtyValue, keyboardMouseSelected, monitorSelected, monitorQtyValue,
                    webSelected, officeSuiteSelected, officeSuiteQtyValue, devToolsSelected, devToolsQtyValue,
                    requesterId, creationTime, "Pending");

            if (orderId != -1) {
                Toast.makeText(this, "Order placed successfully! Order ID: " + orderId, Toast.LENGTH_SHORT).show();
                loadPlacedOrders();
            } else {
                Toast.makeText(this, "Failed to place order.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Invalid input. Please check your selections.", Toast.LENGTH_SHORT).show();
        }
    }


    private void setUpSpinners() {
        DatabaseHelper dbHelper = new DatabaseHelper(this);

        // Charger les composants dynamiques pour les deux premières cases déroulantes
        List<String> dynamicComponents = dbHelper.getAllComponentTitles(); // Composants ajoutés par le StoreKeeper

        // Adapter pour la première case déroulante (e.g., "cases")
        ArrayAdapter<String> adapterCases = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, dynamicComponents);
        adapterCases.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cases.setAdapter(adapterCases);

        // Adapter pour la deuxième case déroulante (e.g., "motherboards")
        ArrayAdapter<String> adapterMotherboards = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, dynamicComponents);
        adapterMotherboards.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        motherboards.setAdapter(adapterMotherboards);

        // Les autres spinners utilisent les valeurs par défaut (statiques)
        ArrayAdapter<CharSequence> adapterRam = ArrayAdapter.createFromResource(this,
                R.array.ram, android.R.layout.simple_spinner_item);
        adapterRam.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ram.setAdapter(adapterRam);

        ArrayAdapter<CharSequence> adapterRamQTY = ArrayAdapter.createFromResource(this,
                R.array.ramQTY, android.R.layout.simple_spinner_item);
        adapterRamQTY.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ramQTY.setAdapter(adapterRamQTY);

        ArrayAdapter<CharSequence> adapterHarddrives = ArrayAdapter.createFromResource(this,
                R.array.harddrives, android.R.layout.simple_spinner_item);
        adapterHarddrives.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        harddrives.setAdapter(adapterHarddrives);

        ArrayAdapter<CharSequence> adapterHarddrivesQTY = ArrayAdapter.createFromResource(this,
                R.array.harddrivesQTY, android.R.layout.simple_spinner_item);
        adapterHarddrivesQTY.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        harddrivesQTY.setAdapter(adapterHarddrivesQTY);

        ArrayAdapter<CharSequence> adapterkandb = ArrayAdapter.createFromResource(this,
                R.array.keyboardsmouse, android.R.layout.simple_spinner_item);
        adapterkandb.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        keyboardsmouse.setAdapter(adapterkandb);

        ArrayAdapter<CharSequence> adapterMonitors = ArrayAdapter.createFromResource(this,
                R.array.monitors, android.R.layout.simple_spinner_item);
        adapterMonitors.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        monitors.setAdapter(adapterMonitors);

        ArrayAdapter<CharSequence> adapterMonitorQTY = ArrayAdapter.createFromResource(this,
                R.array.monitorsQTY, android.R.layout.simple_spinner_item);
        adapterMonitorQTY.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        monitorQTY.setAdapter(adapterMonitorQTY);

        ArrayAdapter<CharSequence> adapterWeb = ArrayAdapter.createFromResource(this,
                R.array.web, android.R.layout.simple_spinner_item);
        adapterWeb.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        web.setAdapter(adapterWeb);

        ArrayAdapter<CharSequence> adapterofficesuite = ArrayAdapter.createFromResource(this,
                R.array.officesuite, android.R.layout.simple_spinner_item);
        adapterofficesuite.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        officesuite.setAdapter(adapterofficesuite);

        ArrayAdapter<CharSequence> adapterofficesuiteQTY = ArrayAdapter.createFromResource(this,
                R.array.officesuiteQTY, android.R.layout.simple_spinner_item);
        adapterofficesuiteQTY.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        officesuiteQTY.setAdapter(adapterofficesuiteQTY);

        ArrayAdapter<CharSequence> adapterdevTools = ArrayAdapter.createFromResource(this,
                R.array.devtools, android.R.layout.simple_spinner_item);
        adapterdevTools.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        devtools.setAdapter(adapterdevTools);

        ArrayAdapter<CharSequence> adapterdevToolsQTY = ArrayAdapter.createFromResource(this,
                R.array.devtoolsQTY, android.R.layout.simple_spinner_item);
        adapterdevToolsQTY.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        devtoolsQTY.setAdapter(adapterdevToolsQTY);
    }



    private void loadPlacedOrders() {
        placedOrdersLayout.removeAllViews(); // Clear previous entries

        Cursor cursor = dbHelper.getPendingOrders();

        if (cursor != null && cursor.moveToFirst()) {
            // Validate columns exist
            int orderIdIndex = cursor.getColumnIndex("order_id");
            int orderDateIndex = cursor.getColumnIndex("order_date");
            int orderStatusIndex = cursor.getColumnIndex("status");

            if (orderIdIndex == -1 || orderDateIndex == -1 || orderStatusIndex == -1) {
                throw new IllegalStateException("Required columns are missing in the result set.");
            }

            do {
                // Fetch order details
                String orderId = cursor.getString(orderIdIndex);
                String orderDate = cursor.getString(orderDateIndex);
                String orderStatus = cursor.getString(orderStatusIndex);

                // Format the date (optional)
                String formattedDate = formatDate(orderDate);

                // Create and add a TextView for each order
                TextView orderView = new TextView(this);
                orderView.setText("Order ID: " + orderId + " | Date: " + formattedDate + " | Status: " + orderStatus);
                orderView.setPadding(10, 10, 10, 10);
                placedOrdersLayout.addView(orderView);
            } while (cursor.moveToNext());
        } else {
            // Handle empty result set
            TextView noOrdersView = new TextView(this);
            noOrdersView.setText("No orders placed yet.");
            noOrdersView.setPadding(10, 10, 10, 10);
            placedOrdersLayout.addView(noOrdersView);
        }

        if (cursor != null) {
            cursor.close(); // Close the cursor
        }
    }



    // Helper method to format the date and time
    private String formatDate(String dateTime) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("EEE, MMM d, yyyy h:mm a", Locale.getDefault());
            Date date = inputFormat.parse(dateTime);
            return outputFormat.format(date);
        } catch (Exception e) {
            e.printStackTrace();
            return dateTime; // Return unformatted date if parsing fails
        }
    }


}
