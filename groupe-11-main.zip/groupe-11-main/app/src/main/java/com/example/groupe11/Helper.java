package com.example.groupe11;

public class Helper {
    String email, password;

    public Helper(String email, String password, String firstName, String lastName) {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Helper(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public Helper() {
    }
}
