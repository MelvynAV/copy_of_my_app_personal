package com.example.groupe11;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Assembler extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private LinearLayout pendingOrdersLayout, acceptedOrdersLayout, shippedOrdersLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assembler);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Initialize layouts
        pendingOrdersLayout = findViewById(R.id.pending_orders_layout);
        acceptedOrdersLayout = findViewById(R.id.accepted_orders_layout);
        shippedOrdersLayout = findViewById(R.id.shipped_orders_layout);

        // Buttons
        Button checkStockButton = findViewById(R.id.check_stock_button);
        Button acceptButton = findViewById(R.id.accept_button);
        Button rejectButton = findViewById(R.id.reject_button);
        Button assembleAndShipButton = findViewById(R.id.assemble_n_ship);
        Button logoutButton = findViewById(R.id.logout);

        // EditTexts
        EditText orderIDAR = findViewById(R.id.orderID_a_r);
        EditText orderIDANS = findViewById(R.id.orderID_a_n_s);

        // Load orders
        loadPendingOrders();
        loadAcceptedOrders();
        loadShippedOrders();

        // Check stock button functionality
        checkStockButton.setOnClickListener(v -> {
            String orderId = orderIDAR.getText().toString();
            if (dbHelper.isStockAvailable(orderId)) {
                Toast.makeText(this, "Stock suffisant pour cette commande.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Stock insuffisant.", Toast.LENGTH_SHORT).show();
            }
        });

        // Accept order button functionality
        acceptButton.setOnClickListener(v -> {
            String orderId = orderIDAR.getText().toString();
            if (dbHelper.acceptOrder(orderId)) {
                Toast.makeText(this, "Commande acceptée.", Toast.LENGTH_SHORT).show();
                loadPendingOrders();
                loadAcceptedOrders();
            } else {
                Toast.makeText(this, "Erreur lors de l'acceptation de la commande.", Toast.LENGTH_SHORT).show();
            }
        });

        // Reject order button functionality
        rejectButton.setOnClickListener(v -> {
            String orderId = orderIDAR.getText().toString();
            if (dbHelper.rejectOrder(orderId)) {
                Toast.makeText(this, "Commande rejetée.", Toast.LENGTH_SHORT).show();
                loadPendingOrders();
            } else {
                Toast.makeText(this, "Erreur lors du rejet de la commande.", Toast.LENGTH_SHORT).show();
            }
        });

        // Assemble and ship button functionality
        assembleAndShipButton.setOnClickListener(v -> {
            String orderId = orderIDANS.getText().toString();
            if (dbHelper.assembleAndShipOrder(orderId)) {
                Toast.makeText(this, "Commande expédiée.", Toast.LENGTH_SHORT).show();
                loadAcceptedOrders();
                loadShippedOrders();
            } else {
                Toast.makeText(this, "Erreur lors de l'expédition de la commande.", Toast.LENGTH_SHORT).show();
            }
        });

        // Logout button functionality
        logoutButton.setOnClickListener(v -> {
            finish();
        });
    }

    private void loadPendingOrders() {
        Cursor cursor = dbHelper.getPendingOrders();
        pendingOrdersLayout.removeAllViews();

        while (cursor.moveToNext()) {
            @SuppressLint("Range") String orderId = cursor.getString(cursor.getColumnIndex("order_id"));
            @SuppressLint("Range") String orderStatus = cursor.getString(cursor.getColumnIndex("status"));

            TextView orderView = new TextView(this);
            orderView.setText("Order ID: " + orderId + " | Status: " + orderStatus);
            orderView.setPadding(10, 10, 10, 10);
            pendingOrdersLayout.addView(orderView);
        }
        cursor.close();
    }


    private void loadAcceptedOrders() {
        Cursor cursor = dbHelper.getAcceptedOrders();
        acceptedOrdersLayout.removeAllViews();
        while (cursor.moveToNext()) {
            TextView orderView = new TextView(this);
            orderView.setText("Commande ID : " + cursor.getString(0));
            acceptedOrdersLayout.addView(orderView);
        }
        cursor.close();
    }

    private void loadShippedOrders() {
        Cursor cursor = dbHelper.getShippedOrders();
        shippedOrdersLayout.removeAllViews();
        while (cursor.moveToNext()) {
            TextView orderView = new TextView(this);
            orderView.setText("Commande ID : " + cursor.getString(0));
            shippedOrdersLayout.addView(orderView);
        }
        cursor.close();
    }
}
