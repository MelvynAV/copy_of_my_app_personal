package com.example.groupe11;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class StockManager {
    private final List<Component> stockList = new ArrayList<>();
    private static StockManager instance;

    public static StockManager getInstance() {
        if (instance == null) {
            instance = new StockManager();
        }
        return instance;
    }

    public void addComponent(String type, String subType, String title, int quantity, LocalDateTime creationLocalDateTime, LocalDateTime modificationLocalDateTime){
        Component component = new Component(type, subType, title, quantity, creationLocalDateTime, modificationLocalDateTime);
        stockList.add(component);
    }

    public void updateComponent(String title, Integer newQuantity, String newComment, LocalDateTime modificationLocalDateTime){
        Component component = findComponentByTitle(title);
        if(component != null){
            if(newQuantity != null){
                component.setQuantity(newQuantity);
            }
            if(newComment != null){
                component.setComment(newComment);
            }
        }
    }


    public void removeComponent(String title){
        Component component = findComponentByTitle(title);
        if(component != null){
            stockList.remove(component);
        }
    }


    public Component viewComponent(String title){
        return findComponentByTitle(title);
    }

    public List<Component> listComponents(){
        return new ArrayList<>(stockList);
    }

    private Component findComponentByTitle(String title){
        for (Component c : stockList){
            if(c.getTitle().equalsIgnoreCase(title)){
                return c;
            }
        }
        return null;
    }
}
