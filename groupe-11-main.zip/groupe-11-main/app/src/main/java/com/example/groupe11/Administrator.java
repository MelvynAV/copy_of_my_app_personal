package com.example.groupe11;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Administrator extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText editTextEmail, editTextPassword;
    private Button buttonAddUser, buttonDeleteUser, buttonSaveChanges, buttonInitializeData, buttonClearDatabase, buttonResetDatabase, buttonResetStock, buttonLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administrator);

        dbHelper = new DatabaseHelper(this);

        editTextEmail = findViewById(R.id.email);
        editTextPassword = findViewById(R.id.password);
        buttonAddUser = findViewById(R.id.add_user);
        buttonDeleteUser = findViewById(R.id.delete_user);
        buttonSaveChanges = findViewById(R.id.save_changes);
        buttonInitializeData = findViewById(R.id.initialize_button);
        buttonClearDatabase = findViewById(R.id.clear_database);
        buttonResetDatabase = findViewById(R.id.reset_database);
        buttonResetStock = findViewById(R.id.reset_stock);
        buttonLogout = findViewById(R.id.logout);

        // Add user
        buttonAddUser.setOnClickListener(view -> {
            String email = editTextEmail.getText().toString();
            String password = editTextPassword.getText().toString();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                if (dbHelper.addUser("Requester", email, password)) {
                    Toast.makeText(this, "User added successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Error adding user", Toast.LENGTH_SHORT).show();
                }
                clearFields();
            }
        });

        // Delete user
        buttonDeleteUser.setOnClickListener(view -> {
            String email = editTextEmail.getText().toString();
            if (dbHelper.deleteUser(email)) {
                Toast.makeText(this, "User deleted successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
            }
            clearFields();
        });

        // Save changes
        buttonSaveChanges.setOnClickListener(view -> {
            String email = editTextEmail.getText().toString();
            String newPassword = editTextPassword.getText().toString();
            if (dbHelper.updateUser(email, newPassword)) {
                Toast.makeText(this, "Password updated successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
            }
            clearFields();
        });

        // Initialize default data
        buttonInitializeData.setOnClickListener(view -> {
            dbHelper.initializeDatabase();
            Toast.makeText(this, "Default data initialized", Toast.LENGTH_SHORT).show();
        });

        // Clear database
        buttonClearDatabase.setOnClickListener(view -> {
            dbHelper.clearDatabase();
            Toast.makeText(this, "Database cleared", Toast.LENGTH_SHORT).show();
        });

        // Reset database
        buttonResetDatabase.setOnClickListener(view -> {
            dbHelper.resetDatabase();
            Toast.makeText(this, "Database reset", Toast.LENGTH_SHORT).show();
        });

        // Reset stock
        buttonResetStock.setOnClickListener(view -> {
            dbHelper.resetStock();
            Toast.makeText(this, "Stock reset", Toast.LENGTH_SHORT).show();
        });

        // Logout
        buttonLogout.setOnClickListener(view -> {
            Intent intent = new Intent(Administrator.this, WelcomePage.class);
            startActivity(intent);
            finish();
        });
    }

    private void clearFields() {
        editTextEmail.setText("");
        editTextPassword.setText("");
    }
}
