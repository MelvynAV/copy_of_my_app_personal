package com.example.groupe11;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class WelcomePage extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText editTextEmail;
    private EditText editTextPassword;
    private Button buttonLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_page);

        dbHelper = new DatabaseHelper(this);
        editTextEmail = findViewById(R.id.email);
        editTextPassword = findViewById(R.id.password);
        buttonLogin = findViewById(R.id.Login);

        buttonLogin.setOnClickListener(view -> {
            String email = editTextEmail.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both email and password", Toast.LENGTH_SHORT).show();
                return;
            }

            if (dbHelper.authenticateUser(email, password)) {
                String role = dbHelper.getUserRole(email);

                // Affichage d'un message de bienvenue
                Toast.makeText(this, "Welcome, " + role, Toast.LENGTH_SHORT).show();

                // Logique de navigation basée sur le rôle
                switch (role) {
                    case "Administrator":
                        Intent adminIntent = new Intent(WelcomePage.this, Administrator.class);
                        startActivity(adminIntent);
                        finish(); // Ferme l'activité WelcomePage
                        break;

                    case "StoreKeeper":
                        Intent storekeeperIntent = new Intent(WelcomePage.this, StoreKeeper.class);
                        startActivity(storekeeperIntent);
                        finish(); // Ferme l'activité WelcomePage
                        break;

                    case "Requester":
                        Intent requesterIntent = new Intent(WelcomePage.this, Requester.class);
                        startActivity(requesterIntent);
                        finish(); // Ferme l'activité WelcomePage
                        break;

                    case "Assembler":
                        Intent assemblerIntent = new Intent(WelcomePage.this, Assembler.class);
                        startActivity(assemblerIntent);
                        finish(); // Ferme l'activité WelcomePage
                        break;

                    default:
                        Toast.makeText(this, "Unknown role", Toast.LENGTH_SHORT).show();
                        break;
                }
            } else {
                // Affiche un message d'erreur si l'authentification échoue
                Toast.makeText(this, "Authentication Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
