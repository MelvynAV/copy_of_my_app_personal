package com.example.groupe11;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class DatabaseInitializer extends AppCompatActivity {
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferences = getSharedPreferences("UserDatabase", MODE_PRIVATE);

        // Supposons que le fichier se trouve dans le répertoire local de l'application
        File file = new File(getFilesDir(), "data.csv");

        // Appel à la fonction d'initialisation
        try {
            initializeFromFile(file);
            Toast.makeText(this, "Initialisation réussie", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "Erreur lors de l'initialisation : " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Initialise les données depuis un fichier CSV et les ajoute dans la base de données.
     * @param file Le fichier CSV contenant les données.
     * @throws IOException en cas de problème de lecture du fichier.
     */
    public void initializeFromFile(File file) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line;

        // Lire chaque ligne du fichier CSV
        while ((line = reader.readLine()) != null) {
            // Supposons que chaque ligne soit au format "email,password,firstName,lastName"
            String[] fields = line.split(",");

            if (fields.length == 4) {
                String email = fields[0].trim();
                String password = fields[1].trim();
                String firstName = fields[2].trim();
                String lastName = fields[3].trim();

                // Ajouter à la base de données partagée sans collision
                addUserToDatabase(email, password, firstName, lastName);
            }
        }

        reader.close();
    }

    /**
     * Ajoute un utilisateur à la base de données partagée.
     * Si l'email existe déjà, il ne sera pas ajouté pour éviter les collisions.
     * @param email L'email de l'utilisateur.
     * @param password Le mot de passe de l'utilisateur.
     * @param firstName Le prénom de l'utilisateur.
     * @param lastName Le nom de famille de l'utilisateur.
     */
    private void addUserToDatabase(String email, String password, String firstName, String lastName) {
        // Vérifier si l'utilisateur existe déjà
        if (sharedPreferences.contains(email + "_password")) {
            Toast.makeText(this, "L'utilisateur " + email + " existe déjà, ajout ignoré.", Toast.LENGTH_SHORT).show();
        } else {
            // Si l'utilisateur n'existe pas, ajouter ses informations
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(email + "_password", password);
            editor.putString(email + "_firstName", firstName);
            editor.putString(email + "_lastName", lastName);
            editor.apply();
            Toast.makeText(this, "Utilisateur " + email + " ajouté avec succès.", Toast.LENGTH_SHORT).show();
        }
    }
}
