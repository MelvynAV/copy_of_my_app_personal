package com.example.groupe11;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class StoreKeeper extends AppCompatActivity {

    private final StockManager stockManager;
    private LinearLayout componentsLinear;
    EditText Type, SubType, Title, Quantity, Comment;
    Button Add, Update, Delete, LogOut;
    LocalDateTime CreationLocalDateTime, ModificationLocalDateTime;
    SharedPreferences sharedPreferences;

    public StoreKeeper() {
        this.stockManager = StockManager.getInstance();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_keeper);

        sharedPreferences = getSharedPreferences("StoreKeeperPrefs", MODE_PRIVATE);

        // Initialisation des vues
        Type = findViewById(R.id.type);
        SubType = findViewById(R.id.sub_type);
        Title = findViewById(R.id.title);
        Quantity = findViewById(R.id.qty);
        Comment = findViewById(R.id.comment);

        Add = findViewById(R.id.add_item);
        Update = findViewById(R.id.update_item);
        Delete = findViewById(R.id.delete_item);
        LogOut = findViewById(R.id.logout);

        componentsLinear = findViewById(R.id.components_linear);

        // Gestion des événements des boutons
        Add.setOnClickListener(view -> addComponent());
        Update.setOnClickListener(view -> updateComponent());
        Delete.setOnClickListener(view -> deleteComponent());
        LogOut.setOnClickListener(view -> logout());

        // Affiche les composants en stock
        displayStockItems();

        // Configuration des marges pour les barres de navigation
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void addComponent() {
        String type = Type.getText().toString().trim();
        String subType = SubType.getText().toString().trim();
        String title = Title.getText().toString().trim();
        String quantityStr = Quantity.getText().toString().trim();
        String comment = Comment.getText().toString().trim();

        if (type.isEmpty() || subType.isEmpty() || title.isEmpty() || quantityStr.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid Quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        String creationTime = LocalDateTime.now().toString();
        String modificationTime = creationTime;

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        boolean success = dbHelper.addStockItem(type, subType, title, quantity, comment, creationTime, modificationTime);

        if (success) {
            Toast.makeText(this, "Component added to stock successfully!", Toast.LENGTH_LONG).show();
            displayStockItems();
            clearFields();
        } else {
            Toast.makeText(this, "Failed to add component", Toast.LENGTH_SHORT).show();
        }
    }


    private void updateComponent() {
        String title = Title.getText().toString().trim();
        String quantityStr = Quantity.getText().toString().trim();
        String comment = Comment.getText().toString().trim();
        Integer newQuantity = null;

        if (title.isEmpty()) {
            Toast.makeText(this, "Title Required", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!quantityStr.isEmpty()) {
            try {
                newQuantity = Integer.parseInt(quantityStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid Quantity", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        ModificationLocalDateTime = LocalDateTime.now();

        stockManager.updateComponent(title, newQuantity, comment, ModificationLocalDateTime);
        saveModificationToSharedPreferences(title, newQuantity, comment, ModificationLocalDateTime);

        displayStockItems();
        clearFields();
        Toast.makeText(this, "Component Successfully Updated", Toast.LENGTH_LONG).show();
    }

    private void deleteComponent() {
        String title = Title.getText().toString().trim();

        if (title.isEmpty()) {
            Toast.makeText(this, "Title Required", Toast.LENGTH_SHORT).show();
            return;
        }

        stockManager.removeComponent(title);
        removeFromSharedPreferences(title);

        displayStockItems();
        clearFields();
        Toast.makeText(this, "Component Successfully Deleted", Toast.LENGTH_LONG).show();
    }

    private void logout() {
        Intent intent = new Intent(this, WelcomePage.class);
        startActivity(intent);
        finish();
    }

    private void displayStockItems() {
        componentsLinear.removeAllViews(); // Clear the existing items in the view

        // Initialize the database helper
        DatabaseHelper dbHelper = new DatabaseHelper(this);

        // Fetch the list of components from the database
        List<String> stockItems = dbHelper.getAllStockItems();

        // Dynamically add each component to the LinearLayout
        for (String item : stockItems) {
            TextView textView = new TextView(this);
            textView.setText(item); // Display the component details
            textView.setPadding(16, 16, 16, 16);
            textView.setTextColor(Color.BLACK); // Optional: Set text color
            componentsLinear.addView(textView); // Add the TextView to the LinearLayout
        }
    }


    private void clearFields() {
        Type.setText("");
        SubType.setText("");
        Title.setText("");
        Quantity.setText("");
        Comment.setText("");
    }

    private void saveToSharedPreferences(String type, String subType, String title, int quantity, String comment, LocalDateTime creationTime, LocalDateTime modificationTime) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(title + "_type", type);
        editor.putString(title + "_subtype", subType);
        editor.putInt(title + "_quantity", quantity);
        editor.putString(title + "_creationTime", creationTime.format(DateTimeFormatter.ISO_DATE_TIME));
        editor.putString(title + "_modificationTime", modificationTime.format(DateTimeFormatter.ISO_DATE_TIME));
        if (!comment.isEmpty()) {
            editor.putString(title + "_comment", comment);
        }
        editor.apply();
    }

    private void saveModificationToSharedPreferences(String title, Integer newQuantity, String newComment, LocalDateTime modificationTime) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(title + "_modificationTime", modificationTime.format(DateTimeFormatter.ISO_DATE_TIME));
        if (newQuantity != null) {
            editor.putInt(title + "_quantity", newQuantity);
        }
        if (!newComment.isEmpty()) {
            editor.putString(title + "_comment", newComment);
        }
        editor.apply();
    }

    private void removeFromSharedPreferences(String title) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(title + "_type");
        editor.remove(title + "_subtype");
        editor.remove(title + "_quantity");
        editor.remove(title + "_comment");
        editor.remove(title + "_creationTime");
        editor.remove(title + "_modificationTime");
        editor.apply();
    }
}
