package com.example.groupe11;

import androidx.test.ext.junit.rules.ActivityScenarioRule;

import org.junit.Rule;
import org.junit.Test;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

public class RequesterTest {

    @Rule
    public ActivityScenarioRule<Requester> activityRule = new ActivityScenarioRule<>(Requester.class);

    @Test
    public void testPlaceOrder() {
        onView(withId(R.id.order_button)).perform(click());
        onView(withText("Order placed successfully!")).check(matches(withText("Order placed successfully!")));
    }

    @Test
    public void testLogout() {
        onView(withId(R.id.logout)).perform(click());

    }
}
