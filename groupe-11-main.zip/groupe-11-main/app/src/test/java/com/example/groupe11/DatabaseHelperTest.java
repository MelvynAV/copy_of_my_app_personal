package com.example.groupe11;

import android.content.Context;
import android.database.Cursor;

import androidx.test.core.app.ApplicationProvider;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class DatabaseHelperTest {
    private DatabaseHelper dbHelper;

    @Before
    public void setUp() {
        Context context = ApplicationProvider.getApplicationContext();
        dbHelper = new DatabaseHelper(context);
    }

    @After
    public void tearDown() {
        dbHelper.close();
    }

    @Test
    public void testAddUser() {
        boolean isAdded = dbHelper.addUser("Requester", "test@example.com", "password123");
        assertTrue(isAdded);
    }

    @Test
    public void testAuthenticateUser() {
        dbHelper.addUser("Requester", "test@example.com", "password123");
        boolean isAuthenticated = dbHelper.authenticateUser("test@example.com", "password123");
        assertTrue(isAuthenticated);
    }

    @Test
    public void testAddOrder() {
        long orderId = dbHelper.addOrderAndGetId(
                "Case A", "Motherboard B", "RAM C", 2,
                "Hard Drive D", 1, "Keyboard Mouse E",
                "Monitor F", 1, "Web G", "Office Suite H", 1,
                "Dev Tools I", 1, "1", "2024-12-01 10:00:00", "Pending"
        );
        assertTrue(orderId > 0);
    }

    @Test
    public void testGetPendingOrders() {
        dbHelper.addOrderAndGetId(
                "Case A", "Motherboard B", "RAM C", 2,
                "Hard Drive D", 1, "Keyboard Mouse E",
                "Monitor F", 1, "Web G", "Office Suite H", 1,
                "Dev Tools I", 1, "1", "2024-12-01 10:00:00", "Pending"
        );
        Cursor cursor = dbHelper.getPendingOrders();
        assertNotNull(cursor);
        assertTrue(cursor.getCount() > 0);
    }

    @Test
    public void testAcceptOrder() {
        long orderId = dbHelper.addOrderAndGetId(
                "Case A", "Motherboard B", "RAM C", 2,
                "Hard Drive D", 1, "Keyboard Mouse E",
                "Monitor F", 1, "Web G", "Office Suite H", 1,
                "Dev Tools I", 1, "1", "2024-12-01 10:00:00", "Pending"
        );
        boolean isAccepted = dbHelper.acceptOrder(String.valueOf(orderId));
        assertTrue(isAccepted);
    }
}
