package com.example.groupe11;

import androidx.test.ext.junit.rules.ActivityScenarioRule;

import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;

import android.os.StrictMode;

public class AssemblerTest {

    @Rule
    public ActivityScenarioRule<Assembler> activityRule = new ActivityScenarioRule<>(Assembler.class);
    @BeforeClass
    public static void disableStrictMode() {
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitAll().build());
    }


    @Test
    public void testCheckStock() {
        onView(withId(R.id.orderID_a_r)).perform(typeText("1"));
        onView(withId(R.id.check_stock_button)).perform(click());
        onView(withText("Stock suffisant pour cette commande.")).check(matches(withText("Stock suffisant pour cette commande.")));
    }

    @Test
    public void testAcceptOrder() {
        onView(withId(R.id.orderID_a_r)).perform(typeText("1"));
        onView(withId(R.id.accept_button)).perform(click());
        onView(withText("Commande acceptée.")).check(matches(withText("Commande acceptée.")));
    }

    @Test
    public void testRejectOrder() {
        onView(withId(R.id.orderID_a_r)).perform(typeText("1"));
        onView(withId(R.id.reject_button)).perform(click());
        onView(withText("Commande rejetée.")).check(matches(withText("Commande rejetée.")));
    }

    @Test
    public void testAssembleAndShip() {
        onView(withId(R.id.orderID_a_n_s)).perform(typeText("1"));
        onView(withId(R.id.assemble_n_ship)).perform(click());
        onView(withText("Commande expédiée.")).check(matches(withText("Commande expédiée.")));
    }
}
